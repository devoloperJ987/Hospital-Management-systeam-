#from doctorlogin import selected_doctor
dname1=""
#print(selected_doctor)
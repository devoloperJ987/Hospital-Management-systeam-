from tkinter import *
import sqlite3
import tkinter.messagebox
import os
import sys


conn = sqlite3.connect('database2.db')
c= conn.cursor()
def login():
    #tkinter.messagebox.showinfo("check")
    #print(selected_doctor.get())
    #print(password_ent.get())
    res=c.execute('SELECT * from database2 WHERE Name=?',(selected_doctor.get(),))
    for i in res.fetchall():
        password_final=i[1]
    if(password_ent.get()==password_final):
        tkinter.messagebox.showinfo("","Successfully logged in")

        

    else:
        tkinter.messagebox.showinfo("","Try again")
        root.destroy()

root=Tk() 
root.title("Doctor's Login")
root.geometry("550x500+0+0")

photo=PhotoImage(file='pic2.png')
label=Label(root,image=photo)
label.pack()

l1= Label(root,text='Name:',font='aerial 16 ')
l2= Label(root,text='Password:',font='aerial 16')

l1.place(x=100,y=100)
l2.place(x=100,y=170)

doctor=["Dr.Rajesh","Dr.Mohan","Dr.Ayushi","Dr.Amol"]
selected_doctor= StringVar(root)
selected_doctor.set(doctor[0])
doctor_ent=OptionMenu(root,selected_doctor,*doctor)

doctor_ent.place(x=250,y=100)


password_ent=Entry(root,show='*',width=20)
password_ent.place(x=250,y=170)

b1=Button(text='Login', width=20, height=2, bg="steelblue",command=login)
b1.place(x=170,y=250)
root.resizable(False,False)




number = []
patients = []

sql = ("SELECT * FROM appointments WHERE doctor=? ",(selected_doctor.get()),)
res = c.execute(sql)
for r in res:
    ids = r[0]
    name = r[1]
    number.append(ids)
    patients.append(name)

# window
class Application:
    def __init__(self, master):
        self.master = master

        self.x = 0
        
        # heading
        self.heading = Label(master, text="Appointments", font=('arial 60 bold'), fg='green')
        self.heading.place(x=350, y=0)

        # button to change patients
        self.change = Button(master, text="Next Patient", width=25, height=2, bg='steelblue', command=self.func)
        self.change.place(x=500, y=600)

        # empty text labels to later config
        self.n = Label(master, text="", font=('arial 200 bold'))
        self.n.place(x=500, y=100)

        self.pname = Label(master, text="", font=('arial 80 bold'))
        self.pname.place(x=500, y=400)
    # function to speak the text and update the text
    def func(self):
        self.n.config(text=str(number[self.x]))
        self.pname.config(text=str(patients[self.x]))
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        rate = engine.getProperty('rate')
        engine.setProperty('rate', rate-50)
        engine.say('Patient number ' + str(number[self.x]) + str(patients[self.x]))
        engine.runAndWait()
        self.x += 1
root1 = Tk()

b = Application(root1)
root1.geometry("1366x768+0+0")
root1.resizable(False, False)



root.mainloop() 
root1.mainloop()


# update the appointments
from tkinter import *
import tkinter.messagebox 
import sqlite3
import os


import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry,Calendar


conn = sqlite3.connect('database.db')
c = conn.cursor()


class Application:
    def back(self):
        root.destroy()
        os.system('python hms_new.py')

    def __init__(self, master):
        self.master = master
        # heading label
        #self.heading = Label(master, text="Update Appointments",  fg='steelblue', font=('arial 40 bold'))
        #self.heading.place(x=10, y=0)
        self.b2=Button(self.master,text='Back', width=5, height=1, bg="steelblue",command=self.back)
        self.b2.place(x=0,y=0)
        # search criteria --id
        self.id = Label(master, text="Enter Patient's ID:", font=('arial 18 bold'),bg='lightgreen')
        self.id.place(x=0, y=60)

        # entry for  the id
        self.idnet = Entry(master, width=30)
        self.idnet.place(x=280, y=62)

        # search button
        self.search = Button(master, text="Search", width=12, height=1, bg='steelblue', command=self.search_db)
        self.search.place(x=350, y=102)


    

    # function to search
    def search_db(self):
        res1="SELECT * FROM appointments"
        self.input = self.idnet.get()
        # execute sql 

        sql = "SELECT * FROM appointments WHERE ID LIKE ?"
        self.res = c.execute(sql, (self.input,))
        for self.row in self.res:
            self.name1 = self.row[1]
            self.age = self.row[2]
            self.gender = self.row[3]
            self.location = self.row[4]
            self.time = self.row[5]
            self.phone = self.row[6]
            self.doctor = self.row[7]
            self.date = self.row[8]
        # creating the update form
        
        
        

        # entries for each labels==========================================================
        # ===================filling the search result in the entry box to update
        try:
            self.ent1 = Entry(self.master, width=30)
            #self.ent1.place(x=300, y=140)
            self.ent1.insert(END, str(self.name1))
        
        except(AttributeError):
            tkinter.messagebox.showinfo("Error","ID not present")

        else:
            self.ent1 = Entry(self.master, width=30)
            self.ent1.place(x=300, y=140)
            self.ent1.insert(END, str(self.name1))

            self.uname = Label(self.master, text="Patient's Name:", font=('arial 18 bold'),bg='lightgreen')
            self.uname.place(x=0, y=140)

            self.uage = Label(self.master, text="Age:", font=('arial 18 bold'),bg='lightgreen')
            self.uage.place(x=0, y=180)

            self.ugender = Label(self.master, text="Gender:", font=('arial 18 bold'),bg='lightgreen')
            self.ugender.place(x=0, y=220)

            self.ulocation = Label(self.master, text="Location:", font=('arial 18 bold'),bg='lightgreen')
            self.ulocation.place(x=0, y=260)

            self.utime = Label(self.master, text="Appointment Time:", font=('arial 18 bold'),bg='lightgreen')
            self.utime.place(x=0, y=300)

            self.uphone = Label(self.master, text="Phone Number:", font=('arial 18 bold'),bg='lightgreen')
            self.uphone.place(x=0, y=340)

            self.udoctor= Label(self.master,text="Doctor:",font='aerial 18 bold',bg='lightgreen')
            self.udoctor.place(x=0,y=380)

            self.udate = Label(self.master,text='Date:',font='aerial 18 bold',bg='lightgreen')
            self.udate.place(x=0,y=420)

            self.ent2 = Entry(self.master, width=30)
            self.ent2.place(x=300, y=180)
            self.ent2.insert(END, str(self.age))

            self.ent3 = Entry(self.master, width=30)
            self.ent3.place(x=300, y=220)
            self.ent3.insert(END, str(self.gender))

            self.ent4 = Entry(self.master, width=30)
            self.ent4.place(x=300, y=260)
            self.ent4.insert(END, str(self.location))

            self.ent5 = Entry(self.master, width=30)
            self.ent5.place(x=300, y=300)
            self.ent5.insert(END, str(self.time))

            self.ent6 = Entry(self.master, width=30)
            self.ent6.place(x=300, y=340)
            self.ent6.insert(END, str(self.phone))

            self.ent7 = Entry(self.master, width=30)
            self.ent7.place(x=300, y=380)
            self.ent7.insert(END, str(self.doctor))

            self.ent8 = Entry(self.master, width=30)
            self.ent8.place(x=300, y=420)
            self.ent8.insert(END, str(self.date))
        
        #except(AttributeError):
           # tkinter.messagebox.showinfo("Error","ID not present")
        
       # else:

            # button to execute update
            self.update = Button(self.master, text="Update", width=20, height=2, bg='lightblue', command=self.update_db)
            self.update.place(x=400, y=460)

            # button to delete
            self.delete = Button(self.master, text="Delete", width=20, height=2, bg='red', command=self.delete_db)
            self.delete.place(x=150, y=460)

        


    def update_db(self):
        # declaring the variables to update
        self.var1 = self.ent1.get() #updated name
        self.var2 = self.ent2.get() #updated age
        self.var3 = self.ent3.get() #updated gender
        self.var4 = self.ent4.get() #updated location
        self.var5 = self.ent5.get() #updated phone
        self.var6 = self.ent6.get() #updated time
        self.var7 = self.ent7.get() #updated doctor

        query = "UPDATE appointments SET name=?, age=?, gender=?, location=?,  scheduled_time=?, phone=?, doctor=? WHERE ID LIKE ?"
        c.execute(query, (self.var1, self.var2, self.var3, self.var4, self.var5, self.var6,self.var7, self.idnet.get(),))
        conn.commit()
        tkinter.messagebox.showinfo("Updated", "Successfully Updated.")
    
    def delete_db(self):
        # delete the appointment
        sql2 = "DELETE FROM appointments WHERE ID LIKE ?"
        c.execute(sql2, (self.idnet.get(),))
        conn.commit()
        tkinter.messagebox.showinfo("Success", "Deleted Successfully")
        self.ent1.destroy()
        self.ent2.destroy()
        self.ent3.destroy()
        self.ent4.destroy()
        self.ent5.destroy()
        self.ent6.destroy()
        self.ent7.destroy()
# creating the object
root = Tk()
root.title('Update Appointments')
b = Application(root)
root.geometry("600x600+0+0")
root.configure(background='lightgreen')


root.resizable(False, False)
root.mainloop()
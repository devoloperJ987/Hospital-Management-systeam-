from tkinter import *
import sqlite3
import tkinter.messagebox

conn= sqlite3.connect('database.db')

c=conn.cursor()

ids= []

class Application:
    def __init__(self,master):
        self.master=master

        self.left= Frame(master,width=600,height=500,bg='lightgreen')
        self.left.pack(fill='none')

       # self.right= Frame(master,width=400, height=720, bg='steelblue')
        #self.right.pack(side=RIGHT) 

       # self.heading= Label(self.left, text="ABC Hospital Appointments",font="aerial 40 bold", fg="black", bg='lightgreen')
        #self.heading.place(x=0,y=0)

        #####
        self.name=Label(self.left, text="Patient's Name:",font="aerial 18 bold", fg="black", bg='lightgreen')
        self.name.place(x=0,y=100)

        self.age=Label(self.left, text="Age:",font="aerial 18 bold", fg="black", bg='lightgreen')
        self.age.place(x=0,y=140)

        self.gender=Label(self.left, text="Gender:",font="aerial 18 bold", fg="black", bg='lightgreen')
        self.gender.place(x=0,y=180)
        
        self.location=Label(self.left, text="Location:",font="aerial 18 bold", fg="black", bg='lightgreen')
        self.location.place(x=0,y=220)

        self.time=Label(self.left, text="Time:",font="aerial 18 bold", fg="black", bg='lightgreen')
        self.time.place(x=0,y=260)

        self.phone=Label(self.left, text="Phone no:",font="aerial 18 bold", fg="black", bg='lightgreen')
        self.phone.place(x=0,y=300)

        self.doctor=Label(self.left,text='Doctor:',font='aerial 18 bold',fg='black',bg='lightgreen')
        self.doctor.place(x=0,y=340)

        #Entries for all labels
        self.name_ent = Entry(self.left, width= 30)
        self.name_ent.place(x=250, y=100)

        self.age_ent = Entry(self.left, width= 30)
        self.age_ent.place(x=250, y=140)

        gender=["Male","Female","Other"]
        self.selected_gender= StringVar(self.master)
        self.selected_gender.set(gender[0])
        self.gender_ent=OptionMenu(self.master,self.selected_gender,*gender)
        self.gender_ent.place(x=250, y=180)

        self.location_ent = Entry(self.left, width= 30)
        self.location_ent.place(x=250, y=220)

        self.time_ent = Entry(self.left, width= 30)
        self.time_ent.place(x=250, y=260)

        self.phone_ent= Entry(self.left, width= 30)
        self.phone_ent.place(x=250,y=300)

        doctor=["Dr.Rajesh","Dr.Mohan","Dr.Ayushi","Dr.Amol"]
        self.selected_doctor= StringVar(self.master)
        self.selected_doctor.set(doctor[0])
        self.doctor_ent=OptionMenu(self.master,self.selected_doctor,*doctor)
        self.doctor_ent.place(x=250,y=340)

        

        #Button
        self.submit= Button(self.left, text = "Add Appoitments", width=20, height=2, bg="steelblue", command=self.add_appointment)
        self.submit.place(x=50, y=400)

        self.submit=Button(self.left,text="Update",width=20,height=2,bg="steelblue")
        self.submit.place(x=250,y=400)

        

        #fixed appointments in right frame
        sql2= "SELECT ID FROM appointments"
        self.result= c.execute(sql2)

        for self.row in self.result:
            self.id = self.row[0]
            ids.append(self.id)

        self.new= sorted(ids)
        self.final_id= self.new[len(ids)-1]

        #display logs in right frame
       # self.logs = Label(self.right, text= "Logs", font=('arial 20 bold'), fg='white', bg='steelblue')
       # self.logs.place(x=0,y=0)

       # self.box = Text(self.right,width=45, height=40)
       # self.box.place(x=20, y=40)
      #  self.box.insert(END, "Total Appointments till now: "+str(self.final_id)+ '\n')
        
   
        
    def add_appointment(self):
        self.val1= self.name_ent.get()
        self.val2= self.age_ent.get()
        self.val3= self.selected_gender.get()
        self.val4= self.location_ent.get()
        self.val5= self.time_ent.get()
        self.val6= self.phone_ent.get()
        self.val7=self.selected_doctor.get()

        if self.val1 == '' or self.val2 == '' or self.val3=='' or self.val4=='' or self.val5=='' or self.val6 == '' or self.val7=='':
            tkinter.messagebox.showinfo("Warning","Please fill all boxes")
        else:
            sql="INSERT INTO 'appointments'  (name, age, gender, location, scheduled_time, phone,doctor) VALUES(?,?,?,?,?,?,?)"
            c.execute(sql, (self.val1, self.val2, self.val3, self.val4, self.val5, self.val6,self.val7))
            conn.commit()
            tkinter.messagebox.showinfo("Success","Appointment for " +str(self.val1)+ " has been created\n Your id is "+str(self.final_id+1))
            
           # self.box.insert(END, "Appointments fixed for "+str(self.val1)+ " at " +str(self.val5))

    #def search(self):
     #   res=c.execute("Select * from appointments where name= ? ",(self.name_ent.get()))
      #  for i in res.fetchall():
       #     self.age_ent.insert(0,i[1])
        #    self.selected_gender.insert(0,i[2])
         #self.time_ent.insert(0,i[4])
           # self.phone_ent.insert(0,i[5])
            #self.selected_doctor.insert(0,i[6])




    
        
root=Tk() 
b=Application(root)


root.geometry("550x500+0+0")

photo=PhotoImage(file='pic5.png')
label=Label(root,image=photo)
label.pack(expand=YES,fill='none')

root.resizable(False,False)
root.mainloop() 




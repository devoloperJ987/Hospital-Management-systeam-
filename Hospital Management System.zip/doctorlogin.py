from tkinter import *
import sqlite3
import tkinter.messagebox
import os
import sys


conn = sqlite3.connect('database2.db')
c = conn.cursor()


def login():
    #global dname
    #tkinter.messagebox.showinfo("check")
    #print(selected_doctor.get())
    #print(password_ent.get())
    dname=selected_doctor.get()
    res=c.execute('SELECT * from database2 WHERE Name=?',(selected_doctor.get(),))
    for i in res.fetchall():
        password_final=i[1]
    if(password_ent.get()==password_final):
        tkinter.messagebox.showinfo("","Successfully logged in")
        dname=selected_doctor.get()
        f=open("doc.txt","w")
        f.write(dname)
        f.close()
        os.system('python display.py')
        
    else:
        tkinter.messagebox.showinfo("","Try again")

def back():
        root.destroy()
        os.system('python login_window.py')

root=Tk() 
root.title("Doctor's Login")
root.geometry("550x500+0+0")

photo=PhotoImage(file='pic2.png')
label=Label(root,image=photo)
label.pack()


l1= Label(root,text='Name:',font='aerial 16 ')
l2= Label(root,text='Password:',font='aerial 16')

l1.place(x=100,y=100)
l2.place(x=100,y=170)

doctor=["Dr.Rajesh","Dr.Mohan","Dr.Ayushi","Dr.Amol"]
selected_doctor= StringVar(root)
selected_doctor.set(doctor[0])
doctor_ent=OptionMenu(root,selected_doctor,*doctor)
dname=selected_doctor

doctor_ent.place(x=250,y=100)


password_ent=Entry(root,show='*',width=20)
password_ent.place(x=250,y=170)

b1=Button(text='Login', width=20, height=2, bg="steelblue",command=login)
b1.place(x=170,y=250)

b2=Button(text='Back', width=5, height=1, bg="steelblue",command=back)
b2.place(x=0,y=0)

root.resizable(0,1)
root.mainloop() 

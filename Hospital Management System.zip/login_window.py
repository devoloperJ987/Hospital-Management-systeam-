
from tkinter import *
import os

def doctor():
    root.destroy()
    os.system('python doctorlogin.py')
    

def patient():
    root.destroy()
    os.system('python hms_new1.py')

root=Tk()
root.title("Login")
root.geometry("600x680+0+0")

photo=PhotoImage(file='download2.png')
label=Label(root,image=photo)
label.pack()

b1=Button(text="Doctor's login", height=2, width=20, bg ='steelblue',command=doctor)
b2=Button(text='Place Appointment',height=2,width=20,bg='steelblue',command=patient)

b1.place(x=100,y=600)
b2.place(x=300,y=600)
root.resizable(0,0)
root.mainloop()
